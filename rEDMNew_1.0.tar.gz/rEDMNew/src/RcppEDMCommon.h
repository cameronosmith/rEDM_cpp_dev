#ifndef RCPPEDMCOMMON
#define RCPPEDMCOMMON

#include <Rcpp.h>
#include <R.h>
#include <iostream>
#include "Common.h"

namespace r = Rcpp;
using std::cout; 
using std::endl;

#endif
