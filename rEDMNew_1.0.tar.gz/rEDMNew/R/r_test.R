rcpp_hello_world <- function(){
	hello_world_cpp_Internal()
}
